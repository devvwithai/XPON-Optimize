import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Server, Globe, Gamepad2, Tag, Phone, Mail, MapPin, Twitter, Github, Youtube, Twitch } from 'lucide-react'

const footerLinks = {
  Hosting: [
    { name: 'Minecraft Servers', path: '/minecraft', icon: Gamepad2 },
    { name: 'Web Hosting', path: '/web-hosting', icon: Globe },
    { name: 'VPS Hosting', path: '/pricing', icon: Server },
    { name: 'Domain Registration', path: '/domains', icon: Tag },
  ],
  Company: [
    { name: 'About Us', path: '/' },
    { name: 'Blog', path: '/' },
    { name: 'Careers', path: '/' },
    { name: 'Partners', path: '/' },
  ],
  Support: [
    { name: 'Help Center', path: '/' },
    { name: 'Status Page', path: '/' },
    { name: 'Contact', path: '/contact' },
    { name: 'API Docs', path: '/' },
  ],
  Legal: [
    { name: 'Privacy Policy', path: '/' },
    { name: 'Terms of Service', path: '/' },
    { name: 'Cookie Policy', path: '/' },
    { name: 'DMCA', path: '/' },
  ],
}

const socialLinks = [
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Github, href: '#', label: 'GitHub' },
  { icon: Youtube, href: '#', label: 'YouTube' },
  { icon: Twitch, href: '#', label: 'Twitch' },
]

export default function Footer() {
  return (
    <footer className="relative bg-black/40 border-t border-white/10">
      {/* Top wave decoration */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-mc-green/50 to-transparent" />

      <div className="max-w-7xl mx-auto section-padding py-16">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 lg:gap-12">
          {/* Brand */}
          <div className="col-span-2 md:col-span-3 lg:col-span-2">
            <Link to="/" className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-br from-mc-green to-emerald-600 rounded-lg flex items-center justify-center">
                <span className="font-minecraft text-white text-xs">B</span>
              </div>
              <span className="font-bold text-xl">
                Block<span className="text-mc-green">Host</span>
              </span>
            </Link>
            <p className="text-white/50 text-sm leading-relaxed mb-6 max-w-sm">
              Premium hosting for Minecraft servers and websites. Built for gamers, developers, and creators who demand performance.
            </p>
            <div className="space-y-3 text-sm text-white/50">
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-mc-green" />
                <span>support@blockhost.gg</span>
              </div>
              <div className="flex items-center gap-3">
                <MapPin className="w-4 h-4 text-mc-green" />
                <span>Global Infrastructure</span>
              </div>
            </div>
          </div>

          {/* Links */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">{category}</h4>
              <ul className="space-y-3">
                {links.map((link) => (
                  <li key={link.name}>
                    <Link
                      to={link.path}
                      className="text-sm text-white/50 hover:text-mc-green transition-colors duration-300 flex items-center gap-2"
                    >
                      {link.icon && <link.icon className="w-3.5 h-3.5" />}
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom */}
        <div className="mt-16 pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-6">
          <p className="text-sm text-white/40">
            © 2026 BlockHost. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            {socialLinks.map((social) => (
              <motion.a
                key={social.label}
                href={social.href}
                whileHover={{ scale: 1.1, y: -2 }}
                whileTap={{ scale: 0.95 }}
                className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center
                           hover:bg-mc-green/20 hover:border-mc-green/30 transition-colors"
                aria-label={social.label}
              >
                <social.icon className="w-5 h-5 text-white/60 hover:text-mc-green" />
              </motion.a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}