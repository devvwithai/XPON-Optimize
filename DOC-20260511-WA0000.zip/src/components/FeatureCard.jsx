import { motion } from 'framer-motion'

export default function FeatureCard({ icon: Icon, title, description, delay = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay }}
      whileHover={{ y: -5, scale: 1.02 }}
      className="glass p-8 rounded-2xl group cursor-pointer"
    >
      <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-mc-green/20 to-emerald-900/20 
                      flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
        <Icon className="w-7 h-7 text-mc-green" />
      </div>
      <h3 className="text-lg font-bold mb-3 group-hover:text-mc-green transition-colors">{title}</h3>
      <p className="text-white/50 text-sm leading-relaxed">{description}</p>
    </motion.div>
  )
}