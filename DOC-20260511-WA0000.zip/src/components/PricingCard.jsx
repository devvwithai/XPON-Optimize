import { motion } from 'framer-motion'
import { Check, Zap, Star, Crown } from 'lucide-react'

const icons = { starter: Zap, pro: Star, enterprise: Crown }

export default function PricingCard({ plan, index, popular = false }) {
  const Icon = icons[plan.icon] || Zap

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.15 }}
      whileHover={{ y: -8 }}
      className={`relative rounded-2xl p-8 ${
        popular
          ? 'bg-gradient-to-b from-mc-green/20 to-emerald-900/20 border-2 border-mc-green/50'
          : 'glass border border-white/10'
      }`}
    >
      {popular && (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-mc-green text-white text-xs font-bold rounded-full">
          MOST POPULAR
        </div>
      )}

      <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-6 ${
        popular ? 'bg-mc-green/20' : 'bg-white/5'
      }`}>
        <Icon className={`w-6 h-6 ${popular ? 'text-mc-green' : 'text-white/60'}`} />
      </div>

      <h3 className="text-xl font-bold mb-2">{plan.name}</h3>
      <p className="text-white/50 text-sm mb-6">{plan.description}</p>

      <div className="mb-8">
        <span className="text-4xl font-bold">${plan.price}</span>
        <span className="text-white/50">/mo</span>
      </div>

      <ul className="space-y-4 mb-8">
        {plan.features.map((feature, i) => (
          <li key={i} className="flex items-start gap-3 text-sm">
            <Check className={`w-5 h-5 mt-0.5 flex-shrink-0 ${popular ? 'text-mc-green' : 'text-white/40'}`} />
            <span className="text-white/70">{feature}</span>
          </li>
        ))}
      </ul>

      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className={`w-full py-3 rounded-xl font-semibold text-sm transition-all ${
          popular
            ? 'bg-mc-green hover:bg-mc-green/90 text-white'
            : 'bg-white/10 hover:bg-white/20 text-white border border-white/20'
        }`}
      >
        Get Started
      </motion.button>
    </motion.div>
  )
}