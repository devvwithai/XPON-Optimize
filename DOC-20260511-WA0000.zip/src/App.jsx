import { Routes, Route } from 'react-router-dom'
import { AnimatePresence } from 'framer-motion'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import Home from './pages/Home'
import MinecraftHosting from './pages/MinecraftHosting'
import WebHosting from './pages/WebHosting'
import Domains from './pages/Domains'
import Pricing from './pages/Pricing'
import Contact from './pages/Contact'

function App() {
  return (
    <div className="min-h-screen bg-mc-dark text-white overflow-x-hidden">
      <Navbar />
      <AnimatePresence mode="wait">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/minecraft" element={<MinecraftHosting />} />
          <Route path="/web-hosting" element={<WebHosting />} />
          <Route path="/domains" element={<Domains />} />
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </AnimatePresence>
      <Footer />
    </div>
  )
}

export default App