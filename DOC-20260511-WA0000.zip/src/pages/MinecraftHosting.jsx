import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { 
  Gamepad2, Cpu, HardDrive, Shield, Zap, Download, Settings, 
  Monitor, Globe, ChevronRight, Check, ArrowRight, Server 
} from 'lucide-react'
import ScrollReveal from '../components/ScrollReveal'
import FeatureCard from '../components/FeatureCard'
import PricingCard from '../components/PricingCard'

const mcFeatures = [
  {
    icon: Cpu,
    title: 'High-Performance CPUs',
    description: 'AMD EPYC 9654 & Intel Xeon W-3400 series. Single-thread performance optimized for Minecraft.',
  },
  {
    icon: HardDrive,
    title: 'NVMe SSD Storage',
    description: 'Gen4 NVMe drives with 7GB/s read speeds. Worlds load instantly, chunk generation is seamless.',
  },
  {
    icon: Shield,
    title: 'Advanced DDoS Protection',
    description: 'Layer 3, 4, and 7 protection. Automatic mitigation with zero impact on gameplay.',
  },
  {
    icon: Zap,
    title: 'Instant Deployment',
    description: 'Your server is online in under 60 seconds. One-click installs for all major versions.',
  },
  {
    icon: Download,
    title: '1-Click Modpacks',
    description: 'CurseForge, Modrinth, FTB, and Technic integration. Install modpacks with a single click.',
  },
  {
    icon: Settings,
    title: 'Full Control Panel',
    description: 'Custom Pterodactyl panel with file manager, console, and advanced configuration options.',
  },
]

const versions = [
  { name: 'Vanilla', desc: 'Latest & snapshots', color: 'from-green-500/20 to-emerald-600/20' },
  { name: 'Paper', desc: 'High-performance fork', color: 'from-blue-500/20 to-cyan-600/20' },
  { name: 'Forge', desc: 'Mod support', color: 'from-orange-500/20 to-amber-600/20' },
  { name: 'Fabric', desc: 'Lightweight mods', color: 'from-purple-500/20 to-violet-600/20' },
  { name: 'Spigot', desc: 'Plugin support', color: 'from-red-500/20 to-rose-600/20' },
  { name: 'Bedrock', desc: 'Cross-platform', color: 'from-teal-500/20 to-emerald-600/20' },
]

const mcPricing = [
  {
    name: 'Dirt',
    description: 'Perfect for friends',
    price: 4.99,
    icon: 'starter',
    features: ['2GB RAM', '20GB NVMe', '1 vCPU', '10 Player Slots', 'Vanilla/Paper', 'Daily Backups'],
  },
  {
    name: 'Stone',
    description: 'Growing community',
    price: 9.99,
    icon: 'pro',
    features: ['4GB RAM', '50GB NVMe', '2 vCPUs', '25 Player Slots', 'All Versions', 'Hourly Backups', 'Mod Support'],
  },
  {
    name: 'Diamond',
    description: 'Serious servers',
    price: 19.99,
    icon: 'enterprise',
    features: ['8GB RAM', '100GB NVMe', '4 vCPUs', 'Unlimited Slots', 'All Versions', 'Real-time Backups', 'Dedicated IP', 'Priority Queue'],
  },
  {
    name: 'Netherite',
    description: 'Enterprise grade',
    price: 39.99,
    icon: 'enterprise',
    features: ['16GB RAM', '200GB NVMe', '8 vCPUs', 'Unlimited Slots', 'All Versions', 'Real-time Backups', 'Dedicated IP', 'Custom Domain', 'Phone Support'],
  },
]

export default function MinecraftHosting() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="pt-20"
    >
      {/* Hero */}
      <section className="relative min-h-[70vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-mc-green/10 via-transparent to-transparent" />
        <div className="max-w-7xl mx-auto section-padding relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-mc-green/10 border border-mc-green/20 mb-6"
              >
                <Gamepad2 className="w-4 h-4 text-mc-green" />
                <span className="text-sm text-mc-green font-medium">Minecraft Server Hosting</span>
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="text-5xl md:text-6xl lg:text-7xl font-black leading-tight mb-6"
              >
                Build Your{' '}
                <span className="gradient-text">World</span>
                <br />
                <span className="text-white/90">Without Lag</span>
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-lg text-white/60 mb-8 max-w-lg leading-relaxed"
              >
                From vanilla survival to massive modpacks. Java, Bedrock, and everything in between. 
                Your server, your rules, our infrastructure.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="flex flex-wrap gap-4"
              >
                <Link to="/pricing" className="btn-primary flex items-center gap-2">
                  View Plans <ArrowRight className="w-5 h-5" />
                </Link>
                <button className="btn-secondary flex items-center gap-2">
                  <Monitor className="w-5 h-5" /> Live Demo
                </button>
              </motion.div>
            </div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.4, duration: 0.8 }}
              className="relative"
            >
              <div className="glass-strong p-8 rounded-3xl">
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-3 h-3 rounded-full bg-red-500" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500" />
                  <div className="w-3 h-3 rounded-full bg-green-500" />
                  <span className="ml-4 text-sm text-white/40">server@blockhost:~$</span>
                </div>
                <div className="font-mono text-sm text-green-400 space-y-2">
                  <p>{`> Starting Minecraft server...`}</p>
                  <p>{`> Loading Paper 1.20.4...`}</p>
                  <p className="text-mc-green">{`> Server started successfully!`}</p>
                  <p>{`> Listening on 0.0.0.0:25565`}</p>
                  <p className="text-mc-diamond">{`> 47 players online`}</p>
                  <p className="text-mc-gold">{`> TPS: 20.0 | MSPT: 12.4`}</p>
                  <p className="text-white/40">{`> Ready for connections...`}</p>
                  <motion.span
                    animate={{ opacity: [1, 0] }}
                    transition={{ duration: 0.8, repeat: Infinity }}
                    className="text-green-400"
                  >
                    _
                  </motion.span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Server Types */}
      <section className="py-24 border-y border-white/5">
        <div className="max-w-7xl mx-auto section-padding">
          <ScrollReveal className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Support for <span className="gradient-text">Every Version</span>
            </h2>
            <p className="text-white/50">Java, Bedrock, and all major server software</p>
          </ScrollReveal>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {versions.map((v, i) => (
              <ScrollReveal key={v.name} delay={i * 0.05}>
                <motion.div
                  whileHover={{ scale: 1.05, y: -5 }}
                  className={`glass p-6 rounded-2xl text-center bg-gradient-to-br ${v.color}`}
                >
                  <Server className="w-8 h-8 text-white/80 mx-auto mb-3" />
                  <h3 className="font-bold mb-1">{v.name}</h3>
                  <p className="text-xs text-white/50">{v.desc}</p>
                </motion.div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-32">
        <div className="max-w-7xl mx-auto section-padding">
          <ScrollReveal className="text-center mb-20">
            <span className="text-mc-green font-semibold text-sm uppercase tracking-wider">Features</span>
            <h2 className="text-4xl md:text-5xl font-bold mt-4 mb-6">
              Built for <span className="gradient-text">Performance</span>
            </h2>
          </ScrollReveal>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mcFeatures.map((f, i) => (
              <FeatureCard key={i} {...f} delay={i * 0.1} />
            ))}
          </div>
        </div>
      </section>

      {/* Performance Stats */}
      <section className="py-24 bg-black/20">
        <div className="max-w-7xl mx-auto section-padding">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { value: '20.0', label: 'Average TPS', sub: 'Consistent tick rate' },
              { value: '< 15ms', label: 'Server Ping', sub: 'Global average' },
              { value: '3s', label: 'World Load', sub: 'For 10GB worlds' },
              { value: '0%', label: 'Packet Loss', sub: 'Guaranteed' },
            ].map((stat, i) => (
              <ScrollReveal key={stat.label} delay={i * 0.1}>
                <div className="text-center">
                  <div className="text-4xl md:text-5xl font-bold gradient-text mb-2">{stat.value}</div>
                  <div className="font-semibold mb-1">{stat.label}</div>
                  <div className="text-sm text-white/50">{stat.sub}</div>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-32">
        <div className="max-w-7xl mx-auto section-padding">
          <ScrollReveal className="text-center mb-20">
            <span className="text-mc-green font-semibold text-sm uppercase tracking-wider">Pricing</span>
            <h2 className="text-4xl md:text-5xl font-bold mt-4 mb-6">
              Pick Your <span className="gradient-text">Tier</span>
            </h2>
          </ScrollReveal>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {mcPricing.map((plan, i) => (
              <PricingCard key={i} plan={plan} index={i} popular={i === 1} />
            ))}
          </div>
        </div>
      </section>
    </motion.div>
  )
}