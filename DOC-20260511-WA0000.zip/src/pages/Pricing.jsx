import { motion } from 'framer-motion'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { 
  Gamepad2, Globe, Tag, Check, ArrowRight, Zap, Star, Crown, 
  Server, Shield, Clock, Headphones, Cpu, HardDrive, Wifi 
} from 'lucide-react'
import ScrollReveal from '../components/ScrollReveal'

const tabs = [
  { id: 'minecraft', label: 'Minecraft', icon: Gamepad2 },
  { id: 'web', label: 'Web Hosting', icon: Globe },
  { id: 'vps', label: 'VPS', icon: Server },
]

const plans = {
  minecraft: [
    {
      name: 'Dirt',
      price: 4.99,
      description: 'Perfect for friends',
      icon: Zap,
      features: ['2GB RAM', '20GB NVMe SSD', '1 vCPU Core', '10 Player Slots', 'Vanilla/Paper Support', 'Daily Backups', 'Basic DDoS Protection', 'Community Support'],
      cta: 'Start with Dirt',
      color: 'from-stone-600 to-stone-700',
    },
    {
      name: 'Stone',
      price: 9.99,
      description: 'Growing communities',
      icon: Star,
      features: ['4GB RAM', '50GB NVMe SSD', '2 vCPU Cores', '25 Player Slots', 'All Versions Supported', 'Hourly Backups', 'Advanced DDoS Protection', 'Priority Support', 'Modpack Installer', 'Custom Domain'],
      cta: 'Get Stone',
      color: 'from-gray-500 to-gray-600',
      popular: true,
    },
    {
      name: 'Diamond',
      price: 19.99,
      description: 'Serious servers',
      icon: Crown,
      features: ['8GB RAM', '100GB NVMe SSD', '4 vCPU Cores', 'Unlimited Slots', 'All Versions + Proxies', 'Real-time Backups', 'Enterprise DDoS Protection', '24/7 Priority Support', 'Custom Modpacks', 'Dedicated IP Address', 'Server Monitoring'],
      cta: 'Go Diamond',
      color: 'from-cyan-500 to-blue-600',
    },
    {
      name: 'Netherite',
      price: 39.99,
      description: 'Enterprise grade',
      icon: Crown,
      features: ['16GB RAM', '200GB NVMe SSD', '8 vCPU Cores', 'Unlimited Everything', 'All Versions + Custom', 'Real-time + Offsite Backups', 'Custom DDoS Rules', 'Dedicated Account Manager', 'White-label Panel', 'Load Balancing', '99.99% SLA'],
      cta: 'Contact Sales',
      color: 'from-mc-dark to-gray-900',
    },
  ],
  web: [
    {
      name: 'Starter',
      price: 3.99,
      description: 'Personal projects',
      icon: Zap,
      features: ['10GB NVMe Storage', '1 Website', 'Free SSL Certificate', 'Daily Backups', '10k Monthly Visits', '5 Email Accounts', 'LiteSpeed Server', 'cPanel Included'],
      cta: 'Start Hosting',
      color: 'from-blue-500 to-cyan-600',
    },
    {
      name: 'Business',
      price: 8.99,
      description: 'Small business sites',
      icon: Star,
      features: ['50GB NVMe Storage', '10 Websites', 'Free SSL + Wildcard', 'Hourly Backups', '100k Monthly Visits', 'Unlimited Emails', 'LiteSpeed + LSCache', 'CDN Included', 'Staging Environment', 'Priority Support'],
      cta: 'Get Business',
      color: 'from-hosting-500 to-hosting-600',
      popular: true,
    },
    {
      name: 'Pro',
      price: 16.99,
      description: 'Growing applications',
      icon: Crown,
      features: ['100GB NVMe Storage', 'Unlimited Websites', 'Free SSL + Wildcard', 'Real-time Backups', '500k Monthly Visits', 'Unlimited Emails', 'LiteSpeed Enterprise', 'Global CDN + WAF', 'Staging + Dev Env', 'Phone Support', 'SSH & WP-CLI Access'],
      cta: 'Go Pro',
      color: 'from-purple-500 to-violet-600',
    },
    {
      name: 'Enterprise',
      price: 49.99,
      description: 'Mission critical',
      icon: Crown,
      features: ['500GB NVMe Storage', 'Unlimited Websites', 'Free SSL + Wildcard', 'Real-time + Offsite', 'Unlimited Visits', 'Unlimited Emails', 'Dedicated Resources', 'Custom WAF Rules', 'Load Balancing', 'Dedicated Manager', '99.99% Uptime SLA', 'Custom Integrations'],
      cta: 'Contact Sales',
      color: 'from-mc-dark to-gray-900',
    },
  ],
  vps: [
    {
      name: 'VPS-1',
      price: 5.99,
      description: 'Entry level VPS',
      icon: Zap,
      features: ['1 vCPU', '2GB RAM', '40GB NVMe', '2TB Transfer', '1 IPv4 Address', 'DDoS Protection', 'Full Root Access', 'KVM Virtualization'],
      cta: 'Deploy VPS-1',
      color: 'from-green-500 to-emerald-600',
    },
    {
      name: 'VPS-2',
      price: 11.99,
      description: 'Balanced performance',
      icon: Star,
      features: ['2 vCPUs', '4GB RAM', '80GB NVMe', '4TB Transfer', '1 IPv4 Address', 'Advanced DDoS', 'Full Root Access', 'KVM Virtualization', 'Snapshots', 'API Access'],
      cta: 'Deploy VPS-2',
      color: 'from-mc-green to-emerald-600',
      popular: true,
    },
    {
      name: 'VPS-4',
      price: 23.99,
      description: 'High performance',
      icon: Crown,
      features: ['4 vCPUs', '8GB RAM', '160GB NVMe', '8TB Transfer', '2 IPv4 Addresses', 'Enterprise DDoS', 'Full Root Access', 'KVM Virtualization', 'Snapshots + Backups', 'API + CLI', 'Load Balancer Ready'],
      cta: 'Deploy VPS-4',
      color: 'from-cyan-500 to-blue-600',
    },
    {
      name: 'VPS-8',
      price: 47.99,
      description: 'Maximum power',
      icon: Crown,
      features: ['8 vCPUs', '16GB RAM', '320GB NVMe', '16TB Transfer', '4 IPv4 Addresses', 'Custom DDoS Rules', 'Full Root Access', 'KVM Virtualization', 'Enterprise Snapshots', 'Full API Suite', 'Dedicated VLAN', '99.99% SLA'],
      cta: 'Contact Sales',
      color: 'from-mc-dark to-gray-900',
    },
  ],
}

const globalFeatures = [
  { icon: Shield, text: 'Enterprise DDoS Protection' },
  { icon: Clock, text: '99.99% Uptime SLA' },
  { icon: Headphones, text: '24/7 Expert Support' },
  { icon: Cpu, text: 'AMD EPYC / Intel Xeon' },
  { icon: HardDrive, text: 'NVMe Gen4 SSD' },
  { icon: Wifi, text: 'Global Anycast Network' },
]

export default function Pricing() {
  const [activeTab, setActiveTab] = useState('minecraft')
  const [billingCycle, setBillingCycle] = useState('monthly')

  const getPrice = (price) => {
    if (billingCycle === 'yearly') {
      return (price * 0.85).toFixed(2)
    }
    if (billingCycle === 'biannual') {
      return (price * 0.75).toFixed(2)
    }
    return price.toFixed(2)
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="pt-20"
    >
      {/* Hero */}
      <section className="relative py-24 text-center">
        <div className="max-w-4xl mx-auto section-padding">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-mc-green/10 border border-mc-green/20 mb-6"
          >
            <Zap className="w-4 h-4 text-mc-green" />
            <span className="text-sm text-mc-green font-medium">Simple, transparent pricing</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-6xl lg:text-7xl font-black mb-6"
          >
            Choose Your{' '}
            <span className="gradient-text">Plan</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-lg text-white/60 mb-10 max-w-2xl mx-auto"
          >
            No hidden fees, no surprises. Scale up or down anytime. 7-day money-back guarantee on all plans.
          </motion.p>

          {/* Billing Toggle */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="inline-flex items-center gap-2 p-1.5 glass rounded-xl"
          >
            {[
              { id: 'monthly', label: 'Monthly' },
              { id: 'yearly', label: 'Yearly (-15%)' },
              { id: 'biannual', label: '2 Years (-25%)' },
            ].map((cycle) => (
              <button
                key={cycle.id}
                onClick={() => setBillingCycle(cycle.id)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  billingCycle === cycle.id
                    ? 'bg-mc-green text-white'
                    : 'text-white/50 hover:text-white'
                }`}
              >
                {cycle.label}
              </button>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Tabs */}
      <section className="sticky top-20 z-40 bg-mc-dark/95 backdrop-blur-xl border-y border-white/5 py-4">
        <div className="max-w-7xl mx-auto section-padding">
          <div className="flex items-center justify-center gap-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-semibold transition-all ${
                  activeTab === tab.id
                    ? 'bg-mc-green/20 text-mc-green border border-mc-green/20'
                    : 'text-white/50 hover:text-white hover:bg-white/5'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Plans Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto section-padding">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {plans[activeTab].map((plan, i) => (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                whileHover={{ y: -8 }}
                className={`relative rounded-2xl p-8 ${
                  plan.popular
                    ? 'bg-gradient-to-b from-mc-green/20 to-emerald-900/20 border-2 border-mc-green/50'
                    : 'glass border border-white/10'
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-mc-green text-white text-xs font-bold rounded-full">
                    MOST POPULAR
                  </div>
                )}

                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${plan.color} flex items-center justify-center mb-6`}>
                  <plan.icon className="w-6 h-6 text-white" />
                </div>

                <h3 className="text-2xl font-bold mb-1">{plan.name}</h3>
                <p className="text-white/50 text-sm mb-6">{plan.description}</p>

                <div className="mb-8">
                  <span className="text-5xl font-bold">${getPrice(plan.price)}</span>
                  <span className="text-white/50">/mo</span>
                  {billingCycle !== 'monthly' && (
                    <div className="text-sm text-mc-green mt-1">
                      Billed {billingCycle === 'yearly' ? 'annually' : 'every 2 years'}
                    </div>
                  )}
                </div>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, j) => (
                    <li key={j} className="flex items-start gap-3 text-sm">
                      <Check className={`w-5 h-5 mt-0.5 flex-shrink-0 ${plan.popular ? 'text-mc-green' : 'text-white/40'}`} />
                      <span className="text-white/70">{feature}</span>
                    </li>
                  ))}
                </ul>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className={`w-full py-3 rounded-xl font-semibold transition-all ${
                    plan.popular
                      ? 'bg-mc-green hover:bg-mc-green/90 text-white'
                      : 'bg-white/10 hover:bg-white/20 text-white border border-white/20'
                  }`}
                >
                  {plan.cta}
                </motion.button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Global Features */}
      <section className="py-24 bg-black/20 border-y border-white/5">
        <div className="max-w-7xl mx-auto section-padding">
          <ScrollReveal className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Included on <span className="gradient-text">Every Plan</span>
            </h2>
          </ScrollReveal>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {globalFeatures.map((f, i) => (
              <ScrollReveal key={i} delay={i * 0.05}>
                <div className="text-center">
                  <div className="w-14 h-14 rounded-xl bg-mc-green/10 flex items-center justify-center mx-auto mb-4">
                    <f.icon className="w-7 h-7 text-mc-green" />
                  </div>
                  <span className="text-sm font-medium">{f.text}</span>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-32">
        <div className="max-w-3xl mx-auto section-padding">
          <ScrollReveal className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Frequently Asked <span className="gradient-text">Questions</span>
            </h2>
          </ScrollReveal>

          <div className="space-y-4">
            {[
              { q: 'Can I upgrade my plan later?', a: 'Yes! You can upgrade or downgrade at any time. Changes take effect immediately, and you only pay the prorated difference.' },
              { q: 'Do you offer refunds?', a: 'We offer a 7-day money-back guarantee on all hosting plans. No questions asked, no hoops to jump through.' },
              { q: 'What payment methods do you accept?', a: 'We accept all major credit cards, PayPal, cryptocurrencies (BTC, ETH, LTC), and bank transfers for enterprise clients.' },
              { q: 'Is there a contract or commitment?', a: 'No long-term contracts required. All plans are month-to-month unless you choose a longer billing cycle for discounts.' },
              { q: 'How do I migrate my existing server?', a: 'Our migration team will transfer your data for free. Just open a ticket and we'll handle everything with zero downtime.' },
            ].map((faq, i) => (
              <ScrollReveal key={i} delay={i * 0.05}>
                <div className="glass p-6 rounded-2xl">
                  <h3 className="font-semibold mb-2">{faq.q}</h3>
                  <p className="text-white/50 text-sm leading-relaxed">{faq.a}</p>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24">
        <div className="max-w-4xl mx-auto section-padding text-center">
          <ScrollReveal>
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Still Have <span className="gradient-text">Questions?</span>
            </h2>
            <p className="text-white/50 text-lg mb-10">
              Our team is ready to help you find the perfect plan for your needs.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/contact" className="btn-primary text-lg px-10">
                Contact Sales
              </Link>
              <button className="btn-secondary text-lg px-10">
                Live Chat
              </button>
            </div>
          </ScrollReveal>
        </div>
      </section>
    </motion.div>
  )
}