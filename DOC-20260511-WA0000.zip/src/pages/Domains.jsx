import { motion } from 'framer-motion'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { 
  Tag, Search, Shield, Lock, Globe, ArrowRight, Check, 
  ChevronRight, Server, Mail, Phone, MapPin, Wifi 
} from 'lucide-react'
import ScrollReveal from '../components/ScrollReveal'

const tlds = [
  { name: '.com', price: 8.99, popular: true },
  { name: '.net', price: 10.99, popular: false },
  { name: '.org', price: 11.99, popular: false },
  { name: '.io', price: 34.99, popular: true },
  { name: '.gg', price: 12.99, popular: true },
  { name: '.co', price: 9.99, popular: false },
  { name: '.dev', price: 14.99, popular: false },
  { name: '.app', price: 16.99, popular: false },
  { name: '.xyz', price: 1.99, popular: false },
  { name: '.me', price: 7.99, popular: false },
  { name: '.tech', price: 6.99, popular: false },
  { name: '.store', price: 5.99, popular: false },
]

const features = [
  {
    icon: Shield,
    title: 'Free WHOIS Privacy',
    description: 'Keep your personal information private. WHOIS privacy included at no extra cost on all domains.',
  },
  {
    icon: Lock,
    title: 'DNSSEC Protection',
    description: 'DNSSEC enabled by default. Protects against DNS spoofing and cache poisoning attacks.',
  },
  {
    icon: Globe,
    title: 'Global DNS',
    description: 'Anycast DNS network across 35+ locations. Sub-20ms resolution times worldwide.',
  },
  {
    icon: Server,
    title: 'Free DNS Hosting',
    description: 'Full DNS management with A, AAAA, CNAME, MX, TXT, SRV records. No hosting required.',
  },
  {
    icon: Mail,
    title: 'Email Forwarding',
    description: 'Create unlimited email forwards. Forward your@domain.com to your existing inbox.',
  },
  {
    icon: Wifi,
    title: 'Domain Forwarding',
    description: 'Redirect domains to any URL. Path forwarding, 301/302 redirects, and masking supported.',
  },
]

export default function Domains() {
  const [searchQuery, setSearchQuery] = useState('')
  const [isSearching, setIsSearching] = useState(false)
  const [searchResults, setSearchResults] = useState(null)

  const handleSearch = (e) => {
    e.preventDefault()
    if (!searchQuery.trim()) return
    setIsSearching(true)
    // Simulate search
    setTimeout(() => {
      setSearchResults([
        { domain: `${searchQuery}.com`, available: Math.random() > 0.3, price: 8.99 },
        { domain: `${searchQuery}.net`, available: Math.random() > 0.3, price: 10.99 },
        { domain: `${searchQuery}.io`, available: Math.random() > 0.5, price: 34.99 },
        { domain: `${searchQuery}.gg`, available: Math.random() > 0.4, price: 12.99 },
        { domain: `${searchQuery}.co`, available: Math.random() > 0.3, price: 9.99 },
      ])
      setIsSearching(false)
    }, 800)
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="pt-20"
    >
      {/* Hero */}
      <section className="relative min-h-[60vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-mc-gold/10 via-transparent to-transparent" />
        <div className="max-w-7xl mx-auto section-padding relative z-10 w-full">
          <div className="text-center max-w-3xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-mc-gold/10 border border-mc-gold/20 mb-6"
            >
              <Tag className="w-4 h-4 text-mc-gold" />
              <span className="text-sm text-mc-gold font-medium">Domain Registration</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-5xl md:text-6xl lg:text-7xl font-black leading-tight mb-6"
            >
              Find Your Perfect{' '}
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-mc-gold to-amber-400">
                Domain
              </span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-lg text-white/60 mb-10"
            >
              Search and register domains with free WHOIS privacy, DNSSEC, and global Anycast DNS.
            </motion.p>

            {/* Search Bar */}
            <motion.form
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              onSubmit={handleSearch}
              className="relative max-w-2xl mx-auto"
            >
              <div className="glass-strong p-2 rounded-2xl flex items-center gap-2">
                <Search className="w-6 h-6 text-white/40 ml-4" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search for your domain..."
                  className="flex-1 bg-transparent border-none outline-none text-lg px-4 py-3 text-white placeholder-white/30"
                />
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  type="submit"
                  disabled={isSearching}
                  className="px-8 py-3 bg-gradient-to-r from-mc-gold to-amber-500 text-black font-bold rounded-xl
                           hover:shadow-lg hover:shadow-mc-gold/25 transition-all disabled:opacity-50"
                >
                  {isSearching ? 'Searching...' : 'Search'}
                </motion.button>
              </div>
            </motion.form>

            {/* Search Results */}
            {searchResults && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-8 glass rounded-2xl overflow-hidden"
              >
                {searchResults.map((result, i) => (
                  <div
                    key={result.domain}
                    className={`flex items-center justify-between p-4 ${
                      i !== searchResults.length - 1 ? 'border-b border-white/5' : ''
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div className={`w-3 h-3 rounded-full ${result.available ? 'bg-green-400' : 'bg-red-400'}`} />
                      <span className="font-semibold">{result.domain}</span>
                      {result.available && (
                        <span className="text-xs px-2 py-1 rounded-full bg-green-500/20 text-green-400">Available</span>
                      )}
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="font-bold">${result.price}/yr</span>
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        disabled={!result.available}
                        className={`px-4 py-2 rounded-lg text-sm font-semibold ${
                          result.available
                            ? 'bg-mc-gold text-black hover:bg-amber-400'
                            : 'bg-white/10 text-white/30 cursor-not-allowed'
                        }`}
                      >
                        {result.available ? 'Add to Cart' : 'Taken'}
                      </motion.button>
                    </div>
                  </div>
                ))}
              </motion.div>
            )}
          </div>
        </div>
      </section>

      {/* TLDs Grid */}
      <section className="py-24 border-y border-white/5">
        <div className="max-w-7xl mx-auto section-padding">
          <ScrollReveal className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Popular <span className="bg-clip-text text-transparent bg-gradient-to-r from-mc-gold to-amber-400">TLDs</span>
            </h2>
            <p className="text-white/50">Competitive pricing on all major domain extensions</p>
          </ScrollReveal>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {tlds.map((tld, i) => (
              <ScrollReveal key={tld.name} delay={i * 0.03}>
                <motion.div
                  whileHover={{ scale: 1.03, y: -3 }}
                  className="glass p-6 rounded-2xl relative"
                >
                  {tld.popular && (
                    <span className="absolute top-3 right-3 text-xs px-2 py-1 rounded-full bg-mc-gold/20 text-mc-gold font-semibold">
                      Popular
                    </span>
                  )}
                  <h3 className="text-2xl font-bold mb-2">{tld.name}</h3>
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl font-bold text-mc-gold">${tld.price}</span>
                    <span className="text-sm text-white/40">/yr</span>
                  </div>
                </motion.div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-32">
        <div className="max-w-7xl mx-auto section-padding">
          <ScrollReveal className="text-center mb-20">
            <span className="text-mc-gold font-semibold text-sm uppercase tracking-wider">Features</span>
            <h2 className="text-4xl md:text-5xl font-bold mt-4 mb-6">
              Everything <span className="bg-clip-text text-transparent bg-gradient-to-r from-mc-gold to-amber-400">Included</span>
            </h2>
          </ScrollReveal>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => (
              <ScrollReveal key={i} delay={i * 0.1}>
                <motion.div
                  whileHover={{ y: -5 }}
                  className="glass p-8 rounded-2xl"
                >
                  <div className="w-14 h-14 rounded-xl bg-mc-gold/10 flex items-center justify-center mb-6">
                    <f.icon className="w-7 h-7 text-mc-gold" />
                  </div>
                  <h3 className="text-lg font-bold mb-3">{f.title}</h3>
                  <p className="text-white/50 text-sm leading-relaxed">{f.description}</p>
                </motion.div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Transfer CTA */}
      <section className="py-24 bg-black/20">
        <div className="max-w-4xl mx-auto section-padding text-center">
          <ScrollReveal>
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Transfer Your <span className="gradient-text">Domains</span>
            </h2>
            <p className="text-white/50 text-lg mb-8 max-w-2xl mx-auto">
              Move your domains to BlockHost and get 1 year free renewal. Free WHOIS privacy and DNSSEC included.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button className="btn-primary bg-gradient-to-r from-mc-gold to-amber-500 text-black">
                Transfer Now
              </button>
              <Link to="/contact" className="btn-secondary">
                Talk to Support
              </Link>
            </div>
          </ScrollReveal>
        </div>
      </section>
    </motion.div>
  )
}