import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { 
  Gamepad2, Globe, Tag, Zap, Shield, Clock, Headphones, Cpu, 
  ChevronRight, ArrowRight, Users, Server, Award, TrendingUp 
} from 'lucide-react'
import AnimatedBackground from '../components/AnimatedBackground'
import ScrollReveal from '../components/ScrollReveal'
import FeatureCard from '../components/FeatureCard'
import StatCounter from '../components/StatCounter'
import PricingCard from '../components/PricingCard'

const features = [
  {
    icon: Zap,
    title: 'Lightning Fast',
    description: 'NVMe SSD storage and DDR5 RAM ensure your server loads in milliseconds. No lag, ever.',
  },
  {
    icon: Shield,
    title: 'DDoS Protection',
    description: 'Enterprise-grade protection against attacks up to 10Tbps. Your server stays online, always.',
  },
  {
    icon: Clock,
    title: '99.99% Uptime',
    description: 'Redundant infrastructure with automatic failover. We guarantee near-perfect availability.',
  },
  {
    icon: Headphones,
    title: '24/7 Support',
    description: 'Real humans, real help. Average response time under 5 minutes for critical issues.',
  },
  {
    icon: Cpu,
    title: 'Latest Hardware',
    description: 'AMD EPYC & Intel Xeon processors. We upgrade hardware before it becomes outdated.',
  },
  {
    icon: Globe,
    title: 'Global Locations',
    description: '15 data centers across NA, EU, Asia & Oceania. Host close to your players.',
  },
]

const stats = [
  { end: 50000, suffix: '+', label: 'Active Servers' },
  { end: 99.99, suffix: '%', label: 'Uptime SLA' },
  { end: 15, suffix: '', label: 'Global Locations' },
  { end: 24, suffix: '/7', label: 'Expert Support' },
]

const pricingPlans = [
  {
    name: 'Starter',
    description: 'Perfect for small servers',
    price: 4.99,
    icon: 'starter',
    features: ['2GB RAM', '20GB NVMe SSD', '1 vCPU Core', 'DDoS Protection', 'Daily Backups', 'Basic Support'],
  },
  {
    name: 'Pro',
    description: 'For growing communities',
    price: 9.99,
    icon: 'pro',
    features: ['4GB RAM', '50GB NVMe SSD', '2 vCPU Cores', 'DDoS Protection', 'Hourly Backups', 'Priority Support', 'Mod Support'],
  },
  {
    name: 'Enterprise',
    description: 'Maximum performance',
    price: 19.99,
    icon: 'enterprise',
    features: ['8GB RAM', '100GB NVMe SSD', '4 vCPU Cores', 'Advanced DDoS', 'Real-time Backups', '24/7 Phone Support', 'Custom Modpacks', 'Dedicated IP'],
  },
]

const testimonials = [
  {
    name: 'Alex Chen',
    role: 'Server Owner',
    content: 'Switched from another host and the difference is night and day. Zero lag, instant support. Best decision ever.',
    avatar: 'AC',
  },
  {
    name: 'Sarah Miller',
    role: 'Community Manager',
    content: 'Our 500-player server runs smoother than ever. The DDoS protection saved us during a targeted attack.',
    avatar: 'SM',
  },
  {
    name: 'Jake Wilson',
    role: 'Developer',
    content: 'The API and control panel are incredibly well-designed. Deploying servers programmatically is a breeze.',
    avatar: 'JW',
  },
]

export default function Home() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      <AnimatedBackground />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
        <div className="absolute inset-0 bg-gradient-to-b from-mc-green/5 via-transparent to-transparent" />

        <div className="relative z-10 max-w-7xl mx-auto section-padding text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-mc-green/10 border border-mc-green/20 mb-8"
          >
            <span className="w-2 h-2 rounded-full bg-mc-green animate-pulse" />
            <span className="text-sm text-mc-green font-medium">Now with 1-click modpack installs</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-black leading-tight mb-6"
          >
            Host Your{' '}
            <span className="gradient-text">World</span>
            <br />
            <span className="text-white/90">Without Limits</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-lg md:text-xl text-white/60 max-w-2xl mx-auto mb-10 leading-relaxed"
          >
            Premium Minecraft server hosting and web infrastructure. 
            Built for speed, secured for peace of mind, priced for everyone.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Link to="/pricing" className="btn-primary flex items-center gap-2 text-lg">
              Start Hosting <ArrowRight className="w-5 h-5" />
            </Link>
            <Link to="/minecraft" className="btn-secondary flex items-center gap-2 text-lg">
              <Gamepad2 className="w-5 h-5" /> Minecraft Plans
            </Link>
          </motion.div>

          {/* Floating cards */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1, duration: 1 }}
            className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto"
          >
            {[
              { icon: Gamepad2, label: 'Minecraft', desc: 'Java & Bedrock', color: 'from-green-500/20 to-emerald-600/20' },
              { icon: Globe, label: 'Web Hosting', desc: 'WordPress & VPS', color: 'from-blue-500/20 to-cyan-600/20' },
              { icon: Tag, label: 'Domains', desc: '.com from $8.99', color: 'from-amber-500/20 to-yellow-600/20' },
            ].map((item, i) => (
              <motion.div
                key={item.label}
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 4, repeat: Infinity, delay: i * 0.5 }}
                className={`glass p-6 rounded-2xl bg-gradient-to-br ${item.color} border border-white/10`}
              >
                <item.icon className="w-8 h-8 text-white/80 mb-3" />
                <h3 className="font-bold text-lg">{item.label}</h3>
                <p className="text-white/50 text-sm">{item.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="relative py-24 border-y border-white/5">
        <div className="max-w-7xl mx-auto section-padding">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
            {stats.map((stat, i) => (
              <StatCounter key={i} {...stat} />
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="relative py-32">
        <div className="max-w-7xl mx-auto section-padding">
          <ScrollReveal className="text-center mb-20">
            <span className="text-mc-green font-semibold text-sm uppercase tracking-wider">Why BlockHost</span>
            <h2 className="text-4xl md:text-5xl font-bold mt-4 mb-6">
              Everything You Need to{' '}
              <span className="gradient-text">Succeed</span>
            </h2>
            <p className="text-white/50 max-w-2xl mx-auto text-lg">
              We have engineered every aspect of our platform to deliver the best hosting experience possible.
            </p>
          </ScrollReveal>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, i) => (
              <FeatureCard key={i} {...feature} delay={i * 0.1} />
            ))}
          </div>
        </div>
      </section>

      {/* Services Bento Grid */}
      <section className="relative py-32 bg-black/20">
        <div className="max-w-7xl mx-auto section-padding">
          <ScrollReveal className="text-center mb-20">
            <span className="text-mc-green font-semibold text-sm uppercase tracking-wider">Our Services</span>
            <h2 className="text-4xl md:text-5xl font-bold mt-4 mb-6">
              One Platform,{' '}
              <span className="gradient-text">Infinite Possibilities</span>
            </h2>
          </ScrollReveal>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 auto-rows-min">
            {/* Minecraft - Large Card */}
            <ScrollReveal className="md:col-span-2 lg:col-span-2 lg:row-span-2">
              <Link to="/minecraft" className="block h-full">
                <motion.div
                  whileHover={{ scale: 1.01 }}
                  className="glass-strong h-full p-10 rounded-3xl relative overflow-hidden group"
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-mc-green/10 to-transparent" />
                  <div className="relative z-10">
                    <div className="w-16 h-16 rounded-2xl bg-mc-green/20 flex items-center justify-center mb-8">
                      <Gamepad2 className="w-8 h-8 text-mc-green" />
                    </div>
                    <h3 className="text-3xl font-bold mb-4">Minecraft Hosting</h3>
                    <p className="text-white/60 text-lg mb-8 max-w-lg">
                      From vanilla to heavy modpacks. Java, Bedrock, and proxy support with automatic updates.
                    </p>
                    <div className="flex items-center gap-4 text-sm text-white/50">
                      <span className="flex items-center gap-2"><Check className="w-4 h-4 text-mc-green" /> Java & Bedrock</span>
                      <span className="flex items-center gap-2"><Check className="w-4 h-4 text-mc-green" /> Modpack Support</span>
                      <span className="flex items-center gap-2"><Check className="w-4 h-4 text-mc-green" /> Auto Backups</span>
                    </div>
                    <div className="mt-8 flex items-center gap-2 text-mc-green font-semibold group-hover:gap-4 transition-all">
                      Explore Plans <ChevronRight className="w-5 h-5" />
                    </div>
                  </div>
                </motion.div>
              </Link>
            </ScrollReveal>

            {/* Web Hosting */}
            <ScrollReveal delay={0.1}>
              <Link to="/web-hosting" className="block h-full">
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  className="glass h-full p-8 rounded-3xl group"
                >
                  <Globe className="w-10 h-10 text-hosting-400 mb-6" />
                  <h3 className="text-xl font-bold mb-3">Web Hosting</h3>
                  <p className="text-white/50 text-sm mb-6">WordPress, VPS, and dedicated servers with 99.99% uptime.</p>
                  <div className="flex items-center gap-2 text-hosting-400 text-sm font-semibold group-hover:gap-3 transition-all">
                    Learn More <ChevronRight className="w-4 h-4" />
                  </div>
                </motion.div>
              </Link>
            </ScrollReveal>

            {/* Domains */}
            <ScrollReveal delay={0.2}>
              <Link to="/domains" className="block h-full">
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  className="glass h-full p-8 rounded-3xl group"
                >
                  <Tag className="w-10 h-10 text-mc-gold mb-6" />
                  <h3 className="text-xl font-bold mb-3">Domain Names</h3>
                  <p className="text-white/50 text-sm mb-6">Register, transfer, and manage domains with free WHOIS privacy.</p>
                  <div className="flex items-center gap-2 text-mc-gold text-sm font-semibold group-hover:gap-3 transition-all">
                    Search Domains <ChevronRight className="w-4 h-4" />
                  </div>
                </motion.div>
              </Link>
            </ScrollReveal>

            {/* Quick Stats */}
            <ScrollReveal delay={0.3} className="md:col-span-2">
              <div className="glass h-full p-8 rounded-3xl flex items-center justify-around">
                {[
                  { icon: Server, value: '< 1s', label: 'Deploy Time' },
                  { icon: Users, value: '50K+', label: 'Customers' },
                  { icon: Award, value: '4.9/5', label: 'Rating' },
                  { icon: TrendingUp, value: '0ms', label: 'Latency' },
                ].map((stat) => (
                  <div key={stat.label} className="text-center">
                    <stat.icon className="w-6 h-6 text-mc-green mx-auto mb-2" />
                    <div className="text-2xl font-bold">{stat.value}</div>
                    <div className="text-xs text-white/50">{stat.label}</div>
                  </div>
                ))}
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* Pricing Preview */}
      <section className="relative py-32">
        <div className="max-w-7xl mx-auto section-padding">
          <ScrollReveal className="text-center mb-20">
            <span className="text-mc-green font-semibold text-sm uppercase tracking-wider">Pricing</span>
            <h2 className="text-4xl md:text-5xl font-bold mt-4 mb-6">
              Simple, Transparent{' '}
              <span className="gradient-text">Pricing</span>
            </h2>
            <p className="text-white/50 max-w-2xl mx-auto text-lg">
              No hidden fees, no surprises. Pay only for what you need.
            </p>
          </ScrollReveal>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {pricingPlans.map((plan, i) => (
              <PricingCard key={i} plan={plan} index={i} popular={i === 1} />
            ))}
          </div>

          <div className="text-center mt-12">
            <Link to="/pricing" className="inline-flex items-center gap-2 text-mc-green font-semibold hover:gap-4 transition-all">
              View Full Pricing <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="relative py-32 bg-black/20">
        <div className="max-w-7xl mx-auto section-padding">
          <ScrollReveal className="text-center mb-20">
            <span className="text-mc-green font-semibold text-sm uppercase tracking-wider">Testimonials</span>
            <h2 className="text-4xl md:text-5xl font-bold mt-4 mb-6">
              Loved by{' '}
              <span className="gradient-text">Thousands</span>
            </h2>
          </ScrollReveal>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((t, i) => (
              <ScrollReveal key={i} delay={i * 0.15}>
                <motion.div
                  whileHover={{ y: -5 }}
                  className="glass p-8 rounded-2xl"
                >
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-mc-green to-emerald-600 flex items-center justify-center font-bold text-sm">
                      {t.avatar}
                    </div>
                    <div>
                      <div className="font-semibold">{t.name}</div>
                      <div className="text-sm text-white/50">{t.role}</div>
                    </div>
                  </div>
                  <p className="text-white/70 text-sm leading-relaxed">"{t.content}"</p>
                  <div className="flex gap-1 mt-4">
                    {[...Array(5)].map((_, j) => (
                      <svg key={j} className="w-4 h-4 text-mc-gold fill-current" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                </motion.div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-32">
        <div className="max-w-4xl mx-auto section-padding text-center">
          <ScrollReveal>
            <h2 className="text-4xl md:text-6xl font-bold mb-6">
              Ready to Start Your{' '}
              <span className="gradient-text">Adventure?</span>
            </h2>
            <p className="text-white/50 text-lg mb-10 max-w-2xl mx-auto">
              Join 50,000+ server owners who trust BlockHost. Deploy your server in under 60 seconds.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/pricing" className="btn-primary text-lg px-10">
                Get Started Free
              </Link>
              <Link to="/contact" className="btn-secondary text-lg px-10">
                Talk to Sales
              </Link>
            </div>
          </ScrollReveal>
        </div>
      </section>
    </motion.div>
  )
}