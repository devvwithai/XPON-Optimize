import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { 
  Globe, Zap, Shield, Clock, HardDrive, Cpu, ArrowRight, 
  Check, Server, Database, Lock, Wifi, Layers, Code, WordpressIcon 
} from 'lucide-react'
import ScrollReveal from '../components/ScrollReveal'
import FeatureCard from '../components/FeatureCard'
import PricingCard from '../components/PricingCard'

const webFeatures = [
  {
    icon: Zap,
    title: 'LiteSpeed Web Server',
    description: 'Up to 10x faster than Apache. Built-in caching and HTTP/3 support for maximum performance.',
  },
  {
    icon: Shield,
    title: 'Free SSL Certificates',
    description: 'AutoSSL with Let's Encrypt. HTTPS enforced by default on all plans. Wildcard support included.',
  },
  {
    icon: Clock,
    title: '99.99% Uptime SLA',
    description: 'Redundant power, network, and cooling. Automatic failover to secondary nodes.',
  },
  {
    icon: HardDrive,
    title: 'NVMe Storage',
    description: 'All plans include NVMe SSD storage. Database queries execute up to 5x faster than SATA.',
  },
  {
    icon: Database,
    title: 'MariaDB & PostgreSQL',
    description: 'Latest database versions with automatic optimization. Remote access available on higher tiers.',
  },
  {
    icon: Lock,
    title: 'Imunify360 Security',
    description: 'Proactive malware scanning, WAF, and intrusion detection. Your site stays clean and secure.',
  },
]

const techStack = [
  { name: 'WordPress', icon: 'W', color: 'bg-blue-500' },
  { name: 'Node.js', icon: 'N', color: 'bg-green-600' },
  { name: 'Python', icon: 'Py', color: 'bg-yellow-500' },
  { name: 'PHP', icon: 'P', color: 'bg-indigo-500' },
  { name: 'Docker', icon: 'D', color: 'bg-blue-600' },
  { name: 'React', icon: 'R', color: 'bg-cyan-500' },
  { name: 'Next.js', icon: 'N', color: 'bg-white text-black' },
  { name: 'MySQL', icon: 'M', color: 'bg-orange-500' },
]

const webPricing = [
  {
    name: 'Starter',
    description: 'Personal projects',
    price: 3.99,
    icon: 'starter',
    features: ['10GB NVMe', '1 Website', 'Free SSL', 'Daily Backups', '10k Visits/mo', 'Email Accounts'],
  },
  {
    name: 'Business',
    description: 'Small business',
    price: 8.99,
    icon: 'pro',
    features: ['50GB NVMe', '10 Websites', 'Free SSL', 'Hourly Backups', '100k Visits/mo', 'Priority Support', 'CDN Included'],
  },
  {
    name: 'Pro',
    description: 'Growing sites',
    price: 16.99,
    icon: 'enterprise',
    features: ['100GB NVMe', 'Unlimited Sites', 'Free SSL', 'Real-time Backups', '500k Visits/mo', 'Phone Support', 'CDN + WAF', 'Staging Env'],
  },
  {
    name: 'Enterprise',
    description: 'Mission critical',
    price: 49.99,
    icon: 'enterprise',
    features: ['500GB NVMe', 'Unlimited Sites', 'Free SSL', 'Real-time Backups', 'Unlimited Visits', 'Dedicated Manager', 'Custom WAF', 'Load Balancer'],
  },
]

export default function WebHosting() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="pt-20"
    >
      {/* Hero */}
      <section className="relative min-h-[70vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-hosting-500/10 via-transparent to-mc-green/5" />
        <div className="max-w-7xl mx-auto section-padding relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-hosting-500/10 border border-hosting-500/20 mb-6"
              >
                <Globe className="w-4 h-4 text-hosting-400" />
                <span className="text-sm text-hosting-400 font-medium">Web Hosting & VPS</span>
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="text-5xl md:text-6xl lg:text-7xl font-black leading-tight mb-6"
              >
                Host Your{' '}
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-hosting-400 to-mc-diamond">
                  Website
                </span>
                <br />
                <span className="text-white/90">At Light Speed</span>
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-lg text-white/60 mb-8 max-w-lg leading-relaxed"
              >
                From simple blogs to complex web applications. LiteSpeed, NVMe storage, 
                and global CDN included on every plan.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="flex flex-wrap gap-4"
              >
                <Link to="/pricing" className="btn-primary flex items-center gap-2 bg-gradient-to-r from-hosting-500 to-hosting-600">
                  View Plans <ArrowRight className="w-5 h-5" />
                </Link>
                <button className="btn-secondary flex items-center gap-2">
                  <Code className="w-5 h-5" /> API Docs
                </button>
              </motion.div>
            </div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.4, duration: 0.8 }}
              className="relative"
            >
              <div className="glass-strong p-8 rounded-3xl">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-2">
                    <Wifi className="w-5 h-5 text-green-400" />
                    <span className="text-sm font-medium">Server Status</span>
                  </div>
                  <span className="text-xs px-2 py-1 rounded-full bg-green-500/20 text-green-400">Operational</span>
                </div>

                <div className="space-y-4">
                  {[
                    { label: 'Response Time', value: '42ms', pct: 95 },
                    { label: 'Uptime (30d)', value: '99.99%', pct: 99.99 },
                    { label: 'Throughput', value: '2.4 GB/s', pct: 78 },
                  ].map((stat) => (
                    <div key={stat.label}>
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-white/60">{stat.label}</span>
                        <span className="font-semibold">{stat.value}</span>
                      </div>
                      <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${stat.pct}%` }}
                          transition={{ duration: 1.5, delay: 0.5 }}
                          className="h-full bg-gradient-to-r from-hosting-400 to-mc-diamond rounded-full"
                        />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 pt-6 border-t border-white/10 grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-hosting-400">15</div>
                    <div className="text-xs text-white/50">Locations</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-mc-green">2.4M</div>
                    <div className="text-xs text-white/50">Websites</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-mc-diamond">0ms</div>
                    <div className="text-xs text-white/50">Downtime</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Tech Stack */}
      <section className="py-24 border-y border-white/5">
        <div className="max-w-7xl mx-auto section-padding">
          <ScrollReveal className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Support for <span className="bg-clip-text text-transparent bg-gradient-to-r from-hosting-400 to-mc-diamond">Any Stack</span>
            </h2>
            <p className="text-white/50">One-click installers for all major frameworks and CMS</p>
          </ScrollReveal>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
            {techStack.map((tech, i) => (
              <ScrollReveal key={tech.name} delay={i * 0.05}>
                <motion.div
                  whileHover={{ scale: 1.1, y: -5 }}
                  className="glass p-4 rounded-xl text-center"
                >
                  <div className={`w-10 h-10 rounded-lg ${tech.color} flex items-center justify-center mx-auto mb-2 font-bold text-sm`}>
                    {tech.icon}
                  </div>
                  <span className="text-xs font-medium">{tech.name}</span>
                </motion.div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-32">
        <div className="max-w-7xl mx-auto section-padding">
          <ScrollReveal className="text-center mb-20">
            <span className="text-hosting-400 font-semibold text-sm uppercase tracking-wider">Features</span>
            <h2 className="text-4xl md:text-5xl font-bold mt-4 mb-6">
              Enterprise Features,{' '}
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-hosting-400 to-mc-diamond">
                Simple Pricing
              </span>
            </h2>
          </ScrollReveal>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {webFeatures.map((f, i) => (
              <FeatureCard key={i} {...f} delay={i * 0.1} />
            ))}
          </div>
        </div>
      </section>

      {/* Comparison Table */}
      <section className="py-24 bg-black/20">
        <div className="max-w-5xl mx-auto section-padding">
          <ScrollReveal className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Why <span className="gradient-text">BlockHost</span>?
            </h2>
          </ScrollReveal>

          <div className="glass overflow-hidden rounded-2xl">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-white/10">
                    <th className="text-left p-6 text-sm font-semibold text-white/60">Feature</th>
                    <th className="text-center p-6 text-sm font-semibold text-mc-green">BlockHost</th>
                    <th className="text-center p-6 text-sm font-semibold text-white/40">Others</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { feature: 'NVMe Storage', us: 'All Plans', them: 'Higher tiers only' },
                    { feature: 'LiteSpeed Server', us: true, them: false },
                    { feature: 'Free SSL', us: true, them: 'Paid add-on' },
                    { feature: 'Daily Backups', us: true, them: 'Weekly only' },
                    { feature: 'DDoS Protection', us: '10Tbps', them: 'Basic' },
                    { feature: 'Staging Environment', us: 'Pro+', them: 'Enterprise only' },
                    { feature: 'Phone Support', us: 'Business+', them: 'Enterprise only' },
                  ].map((row, i) => (
                    <tr key={i} className="border-b border-white/5 last:border-0">
                      <td className="p-6 text-sm">{row.feature}</td>
                      <td className="p-6 text-center">
                        {typeof row.us === 'boolean' ? (
                          <Check className="w-5 h-5 text-mc-green mx-auto" />
                        ) : (
                          <span className="text-mc-green font-semibold text-sm">{row.us}</span>
                        )}
                      </td>
                      <td className="p-6 text-center text-white/40 text-sm">{row.them}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-32">
        <div className="max-w-7xl mx-auto section-padding">
          <ScrollReveal className="text-center mb-20">
            <span className="text-hosting-400 font-semibold text-sm uppercase tracking-wider">Pricing</span>
            <h2 className="text-4xl md:text-5xl font-bold mt-4 mb-6">
              Web Hosting <span className="bg-clip-text text-transparent bg-gradient-to-r from-hosting-400 to-mc-diamond">Plans</span>
            </h2>
          </ScrollReveal>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {webPricing.map((plan, i) => (
              <PricingCard key={i} plan={plan} index={i} popular={i === 1} />
            ))}
          </div>
        </div>
      </section>
    </motion.div>
  )
}