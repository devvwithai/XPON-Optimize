import { motion } from 'framer-motion'
import { useState } from 'react'
import { 
  Mail, Phone, MapPin, Clock, Send, MessageCircle, 
  Twitter, Github, Youtube, Twitch, CheckCircle, AlertCircle 
} from 'lucide-react'
import ScrollReveal from '../components/ScrollReveal'

const contactMethods = [
  {
    icon: MessageCircle,
    title: 'Live Chat',
    description: 'Average response: 2 minutes',
    action: 'Start Chat',
    color: 'text-mc-green',
    bg: 'bg-mc-green/10',
  },
  {
    icon: Mail,
    title: 'Email Support',
    description: 'support@blockhost.gg',
    action: 'Send Email',
    color: 'text-mc-diamond',
    bg: 'bg-mc-diamond/10',
  },
  {
    icon: Phone,
    title: 'Phone Support',
    description: '+1 (555) 123-4567',
    action: 'Call Now',
    color: 'text-mc-gold',
    bg: 'bg-mc-gold/10',
  },
]

const socialLinks = [
  { icon: Twitter, label: 'Twitter', handle: '@BlockHostGG', href: '#' },
  { icon: Github, label: 'GitHub', handle: '@blockhost', href: '#' },
  { icon: Youtube, label: 'YouTube', handle: 'BlockHost', href: '#' },
  { icon: Twitch, label: 'Twitch', handle: 'BlockHostLive', href: '#' },
]

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
    department: 'general',
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsSubmitting(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsSubmitting(false)
    setIsSubmitted(true)
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="pt-20"
    >
      {/* Hero */}
      <section className="relative py-24 text-center">
        <div className="max-w-4xl mx-auto section-padding">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-mc-green/10 border border-mc-green/20 mb-6"
          >
            <MessageCircle className="w-4 h-4 text-mc-green" />
            <span className="text-sm text-mc-green font-medium">We're here to help</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-6xl lg:text-7xl font-black mb-6"
          >
            Get in <span className="gradient-text">Touch</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-lg text-white/60 max-w-2xl mx-auto"
          >
            Have questions about our services? Need a custom solution? 
            Our team is available 24/7 to assist you.
          </motion.p>
        </div>
      </section>

      {/* Contact Methods */}
      <section className="py-16 border-y border-white/5">
        <div className="max-w-7xl mx-auto section-padding">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {contactMethods.map((method, i) => (
              <ScrollReveal key={method.title} delay={i * 0.1}>
                <motion.div
                  whileHover={{ y: -5 }}
                  className="glass p-8 rounded-2xl text-center"
                >
                  <div className={`w-16 h-16 rounded-2xl ${method.bg} flex items-center justify-center mx-auto mb-6`}>
                    <method.icon className={`w-8 h-8 ${method.color}`} />
                  </div>
                  <h3 className="text-xl font-bold mb-2">{method.title}</h3>
                  <p className="text-white/50 text-sm mb-6">{method.description}</p>
                  <button className={`px-6 py-2.5 rounded-xl text-sm font-semibold transition-all ${method.bg} ${method.color} hover:brightness-110`}>
                    {method.action}
                  </button>
                </motion.div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form + Info */}
      <section className="py-32">
        <div className="max-w-7xl mx-auto section-padding">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Form */}
            <ScrollReveal>
              <div className="glass p-8 md:p-10 rounded-3xl">
                <h2 className="text-3xl font-bold mb-2">Send a Message</h2>
                <p className="text-white/50 mb-8">Fill out the form below and we'll get back to you within 24 hours.</p>

                {isSubmitted ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-12"
                  >
                    <CheckCircle className="w-16 h-16 text-mc-green mx-auto mb-4" />
                    <h3 className="text-2xl font-bold mb-2">Message Sent!</h3>
                    <p className="text-white/50">We'll get back to you as soon as possible.</p>
                  </motion.div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium mb-2">Name</label>
                        <input
                          type="text"
                          required
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-white/30
                                   focus:border-mc-green/50 focus:outline-none focus:ring-1 focus:ring-mc-green/50 transition-all"
                          placeholder="Your name"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Email</label>
                        <input
                          type="email"
                          required
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-white/30
                                   focus:border-mc-green/50 focus:outline-none focus:ring-1 focus:ring-mc-green/50 transition-all"
                          placeholder="you@example.com"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium mb-2">Department</label>
                        <select
                          value={formData.department}
                          onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white
                                   focus:border-mc-green/50 focus:outline-none focus:ring-1 focus:ring-mc-green/50 transition-all"
                        >
                          <option value="general">General Inquiry</option>
                          <option value="sales">Sales</option>
                          <option value="support">Technical Support</option>
                          <option value="billing">Billing</option>
                          <option value="abuse">Abuse Report</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Subject</label>
                        <input
                          type="text"
                          required
                          value={formData.subject}
                          onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-white/30
                                   focus:border-mc-green/50 focus:outline-none focus:ring-1 focus:ring-mc-green/50 transition-all"
                          placeholder="How can we help?"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Message</label>
                      <textarea
                        required
                        rows={5}
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-white/30
                                 focus:border-mc-green/50 focus:outline-none focus:ring-1 focus:ring-mc-green/50 transition-all resize-none"
                        placeholder="Tell us about your project or issue..."
                      />
                    </div>

                    <motion.button
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                      disabled={isSubmitting}
                      type="submit"
                      className="w-full py-4 bg-gradient-to-r from-mc-green to-emerald-600 text-white font-semibold rounded-xl
                               hover:shadow-lg hover:shadow-mc-green/25 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          Sending...
                        </>
                      ) : (
                        <>
                          <Send className="w-5 h-5" /> Send Message
                        </>
                      )}
                    </motion.button>
                  </form>
                )}
              </div>
            </ScrollReveal>

            {/* Info */}
            <div className="space-y-8">
              <ScrollReveal delay={0.1}>
                <div className="glass p-8 rounded-2xl">
                  <h3 className="text-xl font-bold mb-6">Office Locations</h3>
                  <div className="space-y-4">
                    {[
                      { city: 'New York, USA', role: 'Headquarters' },
                      { city: 'London, UK', role: 'European Operations' },
                      { city: 'Singapore', role: 'Asia-Pacific Hub' },
                      { city: 'Sydney, Australia', role: 'Oceania Support' },
                    ].map((loc) => (
                      <div key={loc.city} className="flex items-center gap-4">
                        <MapPin className="w-5 h-5 text-mc-green flex-shrink-0" />
                        <div>
                          <div className="font-medium">{loc.city}</div>
                          <div className="text-sm text-white/50">{loc.role}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </ScrollReveal>

              <ScrollReveal delay={0.2}>
                <div className="glass p-8 rounded-2xl">
                  <h3 className="text-xl font-bold mb-6">Support Hours</h3>
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <Clock className="w-5 h-5 text-mc-diamond flex-shrink-0" />
                      <div>
                        <div className="font-medium">Technical Support</div>
                        <div className="text-sm text-mc-green">24/7/365 - Always Online</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <Clock className="w-5 h-5 text-mc-gold flex-shrink-0" />
                      <div>
                        <div className="font-medium">Sales & Billing</div>
                        <div className="text-sm text-white/50">Mon-Fri 9AM-6PM EST</div>
                      </div>
                    </div>
                  </div>
                </div>
              </ScrollReveal>

              <ScrollReveal delay={0.3}>
                <div className="glass p-8 rounded-2xl">
                  <h3 className="text-xl font-bold mb-6">Follow Us</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {socialLinks.map((social) => (
                      <motion.a
                        key={social.label}
                        href={social.href}
                        whileHover={{ scale: 1.02 }}
                        className="flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
                      >
                        <social.icon className="w-5 h-5 text-white/60" />
                        <div>
                          <div className="text-sm font-medium">{social.label}</div>
                          <div className="text-xs text-white/40">{social.handle}</div>
                        </div>
                      </motion.a>
                    ))}
                  </div>
                </div>
              </ScrollReveal>
            </div>
          </div>
        </div>
      </section>

      {/* Map Placeholder */}
      <section className="py-24 bg-black/20">
        <div className="max-w-7xl mx-auto section-padding">
          <ScrollReveal className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Global <span className="gradient-text">Presence</span>
            </h2>
            <p className="text-white/50">15 data centers across 6 continents</p>
          </ScrollReveal>

          <div className="glass rounded-3xl overflow-hidden aspect-[21/9] relative flex items-center justify-center">
            <div className="absolute inset-0 bg-gradient-to-br from-mc-green/5 via-transparent to-mc-diamond/5" />
            <div className="relative z-10 text-center">
              <MapPin className="w-12 h-12 text-mc-green mx-auto mb-4" />
              <p className="text-lg font-semibold">Interactive Map</p>
              <p className="text-sm text-white/50">New York • London • Frankfurt • Singapore • Sydney • Tokyo • São Paulo</p>
            </div>
          </div>
        </div>
      </section>
    </motion.div>
  )
}